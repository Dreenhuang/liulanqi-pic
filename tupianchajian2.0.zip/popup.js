document.getElementById('openViewer').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    if (tabs[0]) {
      try {
        await chrome.scripting.insertCSS({
          target: { tabId: tabs[0].id },
          css: getViewerCSS()
        });
        await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: toggleViewer
        });
        window.close();
      } catch (error) {
        console.error('执行脚本失败:', error);
        alert('无法执行脚本: ' + error.message);
      }
    }
  });
});

function getViewerCSS() {
  return `
#image-viewer-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.95);
  z-index: 999999;
  display: flex;
  flex-direction: column;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
#image-viewer-overlay .viewer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}
#image-viewer-overlay .viewer-title {
  font-size: 18px;
  font-weight: 600;
}
#image-viewer-overlay .viewer-counter {
  font-size: 16px;
  background: rgba(255, 255, 255, 0.2);
  padding: 5px 15px;
  border-radius: 20px;
}
#image-viewer-overlay .viewer-close {
  width: 36px;
  height: 36px;
  border: none;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  font-size: 24px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}
#image-viewer-overlay .viewer-close:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: rotate(90deg);
}
#image-viewer-overlay .viewer-body {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  cursor: zoom-in;
}
#image-viewer-overlay .viewer-prev,
#image-viewer-overlay .viewer-next {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 60px;
  height: 100px;
  background: rgba(255, 255, 255, 0.1);
  border: none;
  color: white;
  font-size: 36px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
}
#image-viewer-overlay .viewer-prev {
  left: 20px;
  border-radius: 0 8px 8px 0;
}
#image-viewer-overlay .viewer-next {
  right: 20px;
  border-radius: 8px 0 0 8px;
}
#image-viewer-overlay .viewer-prev:hover,
#image-viewer-overlay .viewer-next:hover {
  background: rgba(255, 255, 255, 0.25);
  transform: translateY(-50%) scale(1.1);
}
#image-viewer-overlay .viewer-container {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  overflow: auto;
  position: relative;
}
#image-viewer-overlay .viewer-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 10px 50px rgba(0, 0, 0, 0.5);
  transition: transform 0.15s ease;
  cursor: zoom-in;
  flex-shrink: 0;
}
#image-viewer-overlay .viewer-image.zoomed {
  max-width: none;
  max-height: none;
  cursor: grab;
}
#image-viewer-overlay .viewer-image.dragging {
  cursor: grabbing;
}
#image-viewer-overlay.fullscreen-mode .viewer-header,
#image-viewer-overlay.fullscreen-mode .viewer-footer {
  display: none;
}
#image-viewer-overlay.fullscreen-mode .viewer-body {
  height: 100vh;
}
#image-viewer-overlay.fullscreen-mode .viewer-container {
  max-height: 100vh;
}
#image-viewer-overlay .viewer-footer {
  padding: 15px 20px;
  text-align: center;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
#image-viewer-overlay .viewer-hint {
  color: rgba(255, 255, 255, 0.7);
  font-size: 14px;
}
#image-viewer-overlay .viewer-zoom-controls {
  display: flex;
  gap: 10px;
  align-items: center;
}
#image-viewer-overlay .zoom-btn {
  width: 32px;
  height: 32px;
  border: none;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  font-size: 18px;
  border-radius: 5px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
#image-viewer-overlay .zoom-btn:hover {
  background: rgba(255, 255, 255, 0.3);
}
#image-viewer-overlay .zoom-level {
  color: white;
  font-size: 14px;
  min-width: 50px;
  text-align: center;
}
#image-viewer-overlay .viewer-loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 18px;
  background: rgba(0,0,0,0.7);
  padding: 20px 40px;
  border-radius: 10px;
  z-index: 100;
}
#image-viewer-overlay .viewer-size {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  margin-left: 10px;
}
`;
}

function toggleViewer() {
  const existingViewer = document.getElementById('image-viewer-overlay');
  if (existingViewer) {
    existingViewer.remove();
    return;
  }

  const MIN_WIDTH = 800;
  const MIN_HEIGHT = 800;
  let images = [];
  const seen = new Set();
  let currentIndex = 0;
  let viewer, viewerImg, counter, prevBtn, nextBtn, closeBtn, sizeInfo, titleSpan;
  let isLoadingNextPage = false;
  let currentPageNum = 1;
  let baseUrl = '';
  let preloadedPages = [];
  let isFullscreen = false;
  let currentZoom = 1;
  let zoomLevel = null;
  
  function toggleFullscreen() {
    isFullscreen = !isFullscreen;
    if (isFullscreen) {
      viewer.classList.add('fullscreen-mode');
    } else {
      viewer.classList.remove('fullscreen-mode');
    }
  }

  function isValidImageUrl(url) {
    if (!url) return false;
    const lower = url.toLowerCase();
    const invalidPatterns = ['icon', 'logo', 'avatar', 'button', 'loading', 'thumb', 'small', 'banner', 'ad', 'gif'];
    for (const pattern of invalidPatterns) {
      if (lower.includes(pattern)) return false;
    }
    return /\.(jpg|jpeg|png|webp|bmp)(\?.*)?$/i.test(lower);
  }

  function extractImagesFromDoc(doc) {
    const collected = [];
    
    doc.querySelectorAll('img').forEach(img => {
      let src = img.src || img.dataset.src || img.dataset.original || 
                img.getAttribute('data-src') || img.getAttribute('src2') || 
                img.getAttribute('lay-src') || img.getAttribute('data-img');
      
      if (!src || seen.has(src)) return;
      if (!isValidImageUrl(src)) return;
      
      let width = img.naturalWidth || parseInt(img.getAttribute('width')) || 0;
      let height = img.naturalHeight || parseInt(img.getAttribute('height')) || 0;
      
      if (width === 0 || height === 0) {
        const style = img.getAttribute('style') || '';
        const wMatch = style.match(/width[:\s]*(\d+)/i);
        const hMatch = style.match(/height[:\s]*(\d+)/i);
        if (wMatch) width = parseInt(wMatch[1]);
        if (hMatch) height = parseInt(hMatch[1]);
      }
      
      if (width < MIN_WIDTH || height < MIN_HEIGHT) {
        const parent = img.closest('.img, .photo, .tupian, .gallery, .content, article, .post');
        if (parent) {
          width = Math.max(width, 800);
          height = Math.max(height, 800);
        }
      }
      
      if (width >= MIN_WIDTH && height >= MIN_HEIGHT) {
        seen.add(src);
        collected.push({ src: src, width: width, height: height });
      }
    });

    return collected;
  }

  function extractImagesQuick() {
    return extractImagesFromDoc(document);
  }

  function parsePageUrl(url) {
    const match = url.match(/^(.+?)(?:_(\d+))?\.html$/);
    if (match) {
      return {
        baseUrl: match[1],
        pageNum: match[2] ? parseInt(match[2]) : 1
      };
    }
    return null;
  }

  function buildNextPageUrl(base, pageNum) {
    if (pageNum === 1) {
      return base + '_2.html';
    }
    return base + '_' + pageNum + '.html';
  }

  function findNextPageLink() {
    const parsed = parsePageUrl(window.location.href);
    if (parsed) {
      baseUrl = parsed.baseUrl;
      currentPageNum = parsed.pageNum;
      return buildNextPageUrl(baseUrl, currentPageNum);
    }
    return null;
  }

  async function fetchPageImages(url) {
    try {
      console.log('[图片浏览助手] 正在获取:', url);
      const response = await fetch(url);
      if (!response.ok) {
        console.log('[图片浏览助手] 请求失败:', response.status);
        return [];
      }
      const html = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');
      
      const newImages = extractImagesFromDoc(doc);
      console.log('[图片浏览助手] 找到图片:', newImages.length);
      
      return newImages;
    } catch (e) {
      console.error('[图片浏览助手] 获取页面失败:', e);
      return [];
    }
  }

  let isPreloading = false;
  let hasMorePages = true;
  let maxPreloadedPage = 0;

  async function preloadPages() {
    if (!baseUrl || isPreloading) return;
    
    isPreloading = true;
    let preloadPageNum = maxPreloadedPage > 0 ? maxPreloadedPage + 1 : currentPageNum + 1;
    
    while (hasMorePages) {
      const url = buildNextPageUrl(baseUrl, preloadPageNum);
      
      if (preloadedPages.some(p => p.pageNum === preloadPageNum)) {
        preloadPageNum++;
        continue;
      }
      
      console.log('[图片浏览助手] 预加载第', preloadPageNum, '页:', url);
      const newImages = await fetchPageImages(url);
      
      if (newImages.length > 0) {
        preloadedPages.push({ 
          url: url, 
          pageNum: preloadPageNum,
          images: newImages 
        });
        maxPreloadedPage = preloadPageNum;
        console.log('[图片浏览助手] 预加载完成: 第', preloadPageNum, '页', newImages.length, '张');
        
        for (const img of newImages) {
          new Image().src = img.src;
        }
        
        preloadPageNum++;
      } else {
        hasMorePages = false;
        console.log('[图片浏览助手] 没有更多页面了');
        break;
      }
    }
    
    isPreloading = false;
  }

  async function loadNextPage() {
    if (isLoadingNextPage) return { success: false, firstNewIndex: -1 };
    
    isLoadingNextPage = true;
    showLoading('正在加载下一页...');
    
    const nextPage = currentPageNum + 1;
    let newImages = [];
    let firstNewIndex = images.length;
    
    const preloaded = preloadedPages.find(p => p.pageNum === nextPage);
    
    if (preloaded) {
      console.log('[图片浏览助手] 使用预加载数据');
      newImages = preloaded.images;
      preloadedPages = preloadedPages.filter(p => p.pageNum !== nextPage);
    } else {
      const urlToLoad = buildNextPageUrl(baseUrl, nextPage);
      console.log('[图片浏览助手] 加载URL:', urlToLoad);
      newImages = await fetchPageImages(urlToLoad);
    }
    
    if (newImages.length > 0) {
      images = images.concat(newImages);
      currentPageNum = nextPage;
      updateTitle();
      showStatus(`已加载第${currentPageNum}页 (${newImages.length}张)`);
      console.log('[图片浏览助手] 加载成功, 总图片:', images.length);
    } else {
      showStatus('没有更多图片了');
      console.log('[图片浏览助手] 没有更多图片');
    }
    
    hideLoading();
    isLoadingNextPage = false;
    
    return { 
      success: newImages.length > 0, 
      firstNewIndex: newImages.length > 0 ? firstNewIndex : -1 
    };
  }

  function showLoading(text) {
    let loading = document.getElementById('viewer-loading-indicator');
    if (!loading) {
      loading = document.createElement('div');
      loading.id = 'viewer-loading-indicator';
      loading.className = 'viewer-loading';
      viewer.querySelector('.viewer-body').appendChild(loading);
    }
    loading.textContent = text;
    loading.style.display = 'block';
  }

  function hideLoading() {
    const loading = document.getElementById('viewer-loading-indicator');
    if (loading) loading.style.display = 'none';
  }

  function showStatus(text) {
    const status = document.createElement('div');
    status.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(102, 126, 234, 0.9);
      color: white;
      padding: 15px 30px;
      border-radius: 8px;
      font-size: 16px;
      z-index: 1000000;
    `;
    status.textContent = text;
    document.body.appendChild(status);
    setTimeout(() => status.remove(), 1500);
  }

  function updateTitle() {
    if (titleSpan) {
      titleSpan.textContent = `图片浏览 (${images.length}张)`;
    }
  }

  function updateCounter() {
    if (images.length === 0) return;
    counter.textContent = `${currentIndex + 1} / ${images.length}`;
    if (images[currentIndex]) {
      const img = images[currentIndex];
      if (img.width > 0 && img.height > 0) {
        sizeInfo.textContent = `(${img.width}×${img.height})`;
      } else {
        sizeInfo.textContent = '';
      }
    }
  }

  async function showImage(index) {
    if (images.length === 0) return;
    
    if (index >= images.length) {
      const result = await loadNextPage();
      if (result.success && result.firstNewIndex >= 0) {
        index = result.firstNewIndex;
        console.log('[图片浏览助手] 跳转到新图片, index:', index, 'src:', images[index].src);
      } else {
        index = images.length - 1;
      }
    }
    
    if (index < 0) index = 0;
    if (index >= images.length) index = images.length - 1;
    
    currentIndex = index;
    const newSrc = images[currentIndex].src;
    console.log('[图片浏览助手] 显示图片:', currentIndex, newSrc);
    
    viewerImg.style.opacity = '0.5';
    viewerImg.onload = function() {
      viewerImg.style.opacity = '1';
    };
    viewerImg.onerror = function() {
      console.error('[图片浏览助手] 图片加载失败:', newSrc);
      viewerImg.style.opacity = '1';
    };
    viewerImg.src = newSrc;
    updateCounter();
    
    currentZoom = 1;
    viewerImg.style.transform = 'scale(1)';
    viewerImg.classList.remove('zoomed');
    if (zoomLevel) {
      zoomLevel.textContent = '100%';
    }
  }

  function closeViewer() {
    viewer.remove();
    document.body.style.overflow = '';
    document.removeEventListener('keydown', handleKeydown);
  }

  async function handleKeydown(e) {
    switch(e.key) {
      case 'ArrowLeft':
        await showImage(currentIndex - 1);
        break;
      case 'ArrowRight':
        await showImage(currentIndex + 1);
        break;
      case 'Escape':
        if (isFullscreen) {
          toggleFullscreen();
        } else {
          closeViewer();
        }
        break;
      case 'f':
      case 'F':
        toggleFullscreen();
        break;
      case ' ':
        e.preventDefault();
        const result = await loadNextPage();
        if (result.success && result.firstNewIndex >= 0) {
          currentIndex = result.firstNewIndex;
          const newSrc = images[currentIndex].src;
          console.log('[图片浏览助手] 空格加载, 显示图片:', currentIndex, newSrc);
          
          viewerImg.style.opacity = '0.5';
          viewerImg.onload = function() {
            viewerImg.style.opacity = '1';
          };
          viewerImg.onerror = function() {
            console.error('[图片浏览助手] 图片加载失败:', newSrc);
            viewerImg.style.opacity = '1';
          };
          viewerImg.src = newSrc;
          updateCounter();
          
          currentZoom = 1;
          viewerImg.style.transform = 'scale(1)';
          viewerImg.classList.remove('zoomed');
          if (zoomLevel) {
            zoomLevel.textContent = '100%';
          }
        }
        break;
    }
  }

  images = extractImagesQuick();
  
  if (images.length === 0) {
    alert('未找到大尺寸图片（需要宽度和高度均超过800像素）');
    return;
  }

  findNextPageLink();

  viewer = document.createElement('div');
  viewer.id = 'image-viewer-overlay';
  viewer.innerHTML = `
    <div class="viewer-header">
      <span class="viewer-title">图片浏览 (${images.length}张)</span>
      <span class="viewer-counter">1 / ${images.length}</span>
      <span class="viewer-size"></span>
      <button class="viewer-close">&times;</button>
    </div>
    <div class="viewer-body">
      <button class="viewer-prev">&#10094;</button>
      <div class="viewer-container">
        <img class="viewer-image" src="${images[0].src}" alt="图片">
      </div>
      <button class="viewer-next">&#10095;</button>
    </div>
    <div class="viewer-footer">
      <span class="viewer-hint">← → 切换 | ESC 关闭 | 空格 加载下一页 | 滚轮缩放 | F全屏</span>
      <div class="viewer-zoom-controls">
        <button class="zoom-btn" id="zoom-out">−</button>
        <span class="zoom-level">100%</span>
        <button class="zoom-btn" id="zoom-in">+</button>
        <button class="zoom-btn" id="zoom-fit">⊡</button>
        <button class="zoom-btn" id="fullscreen-btn">⛶</button>
      </div>
    </div>
  `;

  document.body.appendChild(viewer);
  document.body.style.overflow = 'hidden';

  titleSpan = viewer.querySelector('.viewer-title');
  viewerImg = viewer.querySelector('.viewer-image');
  counter = viewer.querySelector('.viewer-counter');
  sizeInfo = viewer.querySelector('.viewer-size');
  prevBtn = viewer.querySelector('.viewer-prev');
  nextBtn = viewer.querySelector('.viewer-next');
  closeBtn = viewer.querySelector('.viewer-close');
  
  const zoomInBtn = viewer.querySelector('#zoom-in');
  const zoomOutBtn = viewer.querySelector('#zoom-out');
  const zoomFitBtn = viewer.querySelector('#zoom-fit');
  zoomLevel = viewer.querySelector('.zoom-level');
  const fullscreenBtn = viewer.querySelector('#fullscreen-btn');
  const container = viewer.querySelector('.viewer-container');
  
  let isDragging = false;
  let dragStartX, dragStartY, scrollStartX, scrollStartY;
  
  fullscreenBtn.addEventListener('click', toggleFullscreen);
  
  viewerImg.addEventListener('mousedown', (e) => {
    if (currentZoom > 1) {
      isDragging = true;
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      scrollStartX = container.scrollLeft;
      scrollStartY = container.scrollTop;
      viewerImg.classList.add('dragging');
      e.preventDefault();
    }
  });
  
  document.addEventListener('mousemove', (e) => {
    if (isDragging) {
      const dx = dragStartX - e.clientX;
      const dy = dragStartY - e.clientY;
      container.scrollLeft = scrollStartX + dx;
      container.scrollTop = scrollStartY + dy;
    }
  });
  
  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      viewerImg.classList.remove('dragging');
    }
  });
  
  function updateZoom(newZoom, centerX, centerY) {
    const oldZoom = currentZoom;
    currentZoom = Math.max(0.1, Math.min(10, newZoom));
    
    viewerImg.style.transform = `scale(${currentZoom})`;
    zoomLevel.textContent = Math.round(currentZoom * 100) + '%';
    
    if (currentZoom > 1) {
      viewerImg.classList.add('zoomed');
    } else {
      viewerImg.classList.remove('zoomed');
    }
  }
  
  zoomInBtn.addEventListener('click', () => updateZoom(currentZoom * 1.25));
  zoomOutBtn.addEventListener('click', () => updateZoom(currentZoom / 1.25));
  zoomFitBtn.addEventListener('click', () => updateZoom(1));
  
  container.addEventListener('wheel', (e) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.9 : 1.1;
      updateZoom(currentZoom * delta);
    }
  }, { passive: false });
  
  viewerImg.addEventListener('click', (e) => {
    if (currentZoom === 1) {
      updateZoom(2);
    } else {
      updateZoom(1);
    }
  });

  prevBtn.addEventListener('click', async () => await showImage(currentIndex - 1));
  nextBtn.addEventListener('click', async () => await showImage(currentIndex + 1));
  closeBtn.addEventListener('click', closeViewer);
  viewer.addEventListener('click', (e) => { if (e.target === viewer) closeViewer(); });
  document.addEventListener('keydown', handleKeydown);

  for (let i = 0; i < Math.min(5, images.length); i++) {
    new Image().src = images[i].src;
  }

  updateCounter();
  
  preloadPages();
}
